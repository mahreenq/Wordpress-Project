=== Core Functionality ===

This plugin contains all of your site's core functionality so that it remains theme-independent.

**Requires at least**: WP 3.8
**Tested up to**: WP 4.3.1
**License**: GPLv2

== Changelog ==

= 1.0 =
* Initial release.
